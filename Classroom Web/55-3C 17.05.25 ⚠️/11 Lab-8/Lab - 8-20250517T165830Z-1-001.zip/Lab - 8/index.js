const myBox = document.getElementById("myBox");
const myButton = document.getElementById("myButton");
const myButton2 = document.getElementById("myButton2");
// event : click, mouseover, mouseout
// addEventListener : callback, anonymous, arrow, keyup, keydown

// myBox.addEventListener(event,callback);

// callback
// function changeColor(event){
//     event.target.style.backgroundColor = "tomato";
//     event.target.textContent = "He he, You low CG stupid";
// }
// target is what we clicked on
// event is an object, provided by the web browser automatically

// anonymous function
// myBox.addEventListener("click",function(event){
//     event.target.style.backgroundColor = "tomato";
//     event.target.textContent = "He he, You low CG stupid";
// });

// arrow function
// myBox.addEventListener("click",event=>{
//         event.target.style.backgroundColor = "tomato";
//         event.target.textContent = "He he, You low CG stupid";
//     });

// myBox.addEventListener("mouseover",event=>{
//     event.target.style.backgroundColor = "green";
//     event.target.textContent = "You will blessed with an A+. CLICK!!";
// });

// myBox.addEventListener("mouseout",event=>{
//     event.target.style.backgroundColor = "yellow";
//     event.target.textContent = "Don't miss out the chance. Easy 4.00. CLICK!!";
// });

myButton.addEventListener("click",event=>{
    myBox.style.backgroundColor = "tomato";
    myBox.textContent = "He he, You low CG stupid";
});

myButton.addEventListener("mouseover",event=>{
    myBox.style.backgroundColor = "green";
    myBox.textContent = "You will blessed with an A+. CLICK!!";
});

myButton.addEventListener("mouseout",event=>{
    myBox.style.backgroundColor = "yellow";
    myBox.textContent = "Don't miss out the chance. Easy 4.00. CLICK!!";
});

const moveAmount = 10;
let x = 0;
let y = 0;
document.addEventListener("keydown", event=>{

    // console.log(event.key)
    if(event.key.startsWith("Arrow")){
        switch(event.key){
            case "ArrowUp":
                y-=moveAmount;
                break;
            case "ArrowDown":
                y+=moveAmount;
                break;
            case "ArrowLeft":
                x-=moveAmount;
                break;
            case "ArrowRight":
                x+=moveAmount;
                break;
        }
        myBox.style.top = `${y}px`;
        myBox.style.left = `${x}px`;
    }
});

// myButton2.addEventListener("click",event=>{

//     if(myBox.style.display === "none"){
//         myBox.style.display ="block";
//         myButton2.textContent ="hide";
//     }
//     else{
//         myBox.style.display = "none";
//         myButton2.textContent ="show";
//     }
    
// });


// reserve space -> display = visibility
myButton2.addEventListener("click",event=>{

    if(myBox.style.visibility === "hidden"){
        myBox.style.visibility ="visible";
        myButton2.textContent ="hide";
    }
    else{
        myBox.style.visibility = "hidden";
        myButton2.textContent ="show";
    }
    
});