// How to Use:
// Include the JavaScript File: Make sure to link this script.js file to your HTML file by adding the following line before the closing </body> tag in your HTML file:

// html
// Copy code
// <script src="script.js"></script>

document.addEventListener('DOMContentLoaded', () => {
    // Change background color on button click
    const changeBgButton = document.createElement('button');
    changeBgButton.innerText = 'Change Background';
    changeBgButton.id = 'changeBackground';
    document.querySelector('.container').appendChild(changeBgButton);

    changeBgButton.addEventListener('click', () => {
        document.body.style.backgroundColor = getRandomColor();
    });

    // Function to generate random color
    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    // Scroll to top button
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.innerText = 'Scroll to Top';
    scrollToTopBtn.id = 'scrollToTop';
    document.querySelector('.container').appendChild(scrollToTopBtn);

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollToTopBtn.style.display = 'block';
        } else {
            scrollToTopBtn.style.display = 'none';
        }
    });

    scrollToTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});


